package com.company;

public interface Expression {
    int evaluate();
}
